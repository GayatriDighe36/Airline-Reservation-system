package com.acc.model;

public class Flight {
	
	    private String flightNumber;
	    private String destination;
	    private int capacity;

	    public Flight(String flightNumber, String destination, int capacity) {
	        this.flightNumber = flightNumber;
	        this.destination = destination;
	        this.capacity = capacity;
	    }

	    public String getFlightNumber() {
	        return flightNumber;
	    }

	    public String getDestination() {
	        return destination;
	    }

	    public int getCapacity() {
	        return capacity;
	    }

	    @Override
	    public String toString() {
	        return "Flight Number: " + flightNumber +
	               ", Destination: " + destination +
	               ", Capacity: " + capacity;
	    }
	}


