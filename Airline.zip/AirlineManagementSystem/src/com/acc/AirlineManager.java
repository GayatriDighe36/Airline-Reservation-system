package com.acc;
import java.util.Scanner;

import com.acc.model.Flight;
import com.acc.service.*;
	
public class AirlineManager {
	
	    public static void main(String[] args) {
	        AirlineService airlineService = new AirlineServiceImpl();
	        Scanner scanner = new Scanner(System.in);

	        while (true) {
	            System.out.println("\n--- Airline Reservation System ---");
	            System.out.println("1. Add Flight");
	            System.out.println("2. View Flights");
	            System.out.println("3. Book Ticket");
	            System.out.println("4. Cancel Ticket");
	            System.out.println("5. Exit");
	            System.out.print("Choose an option: ");

	            int choice = scanner.nextInt();
	            scanner.nextLine();

	            switch (choice) {
	                case 1:
	                    System.out.print("Enter Flight Number: ");
	                    String flightNumber = scanner.nextLine();
	                    System.out.print("Enter Destination: ");
	                    String destination = scanner.nextLine();
	                    System.out.print("Enter Capacity: ");
	                    int capacity = scanner.nextInt();
	                    scanner.nextLine();

	                    Flight flight = new Flight(flightNumber, destination, capacity);
	                    airlineService.addFlight(flight);
	                    break;

	                case 2:
	                    airlineService.viewFlights();
	                    break;

	                case 3:
	                    System.out.print("Enter Flight Number: ");
	                    String flightNum = scanner.nextLine();
	                    System.out.print("Enter Passenger Name: ");
	                    String passengerName = scanner.nextLine();
	                    System.out.print("Enter Contact Info: ");
	                    String contactInfo = scanner.nextLine();

	                    airlineService.bookTicket(flightNum, passengerName, contactInfo);
	                    break;

	                case 4:
	                    System.out.print("Enter Reservation ID: ");
	                    String reservationId = scanner.nextLine();
	                    airlineService.cancelTicket(reservationId);
	                    break;

	                case 5:
	                    System.out.println("Exiting...");
	                    return;

	                default:
	                    System.out.println("Invalid choice. Please try again.");
	            }
	        }
	    }
	}


