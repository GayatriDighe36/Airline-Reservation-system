package com.acc.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
	public static Connection getDBConnection() {
		Connection con = null;  //initailize
		try 
		{
			Class.forName("com.mysql.cj.jdbc.Driver");       //cj for this version
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/airline?useSSL=false","root","root");
		}
		catch(ClassNotFoundException e) 
		{
			e.printStackTrace();
		}
		catch(SQLException e) 
		{
			e.printStackTrace();
		}
		return con;
	}
}
