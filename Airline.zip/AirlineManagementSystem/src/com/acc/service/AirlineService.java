package com.acc.service;

import com.acc.model.Flight;

public interface AirlineService {
	public void addFlight(Flight flight);
    public void viewFlights();
    public void bookTicket(String flightNumber, String passengerName, String contactInfo);
    public void cancelTicket(String reservationId);
}
