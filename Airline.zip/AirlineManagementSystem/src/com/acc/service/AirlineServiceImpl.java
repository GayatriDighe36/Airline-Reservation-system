package com.acc.service;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Random;

import com.acc.model.Flight;
import com.acc.util.DBConnection;


public class AirlineServiceImpl implements AirlineService {

	    @Override
	    public void addFlight(Flight flight) {
	        Connection con = null;
	        PreparedStatement pstmt = null;

	        try {
	            con = DBConnection.getDBConnection();
	            String query = "INSERT INTO Flights (flight_number, destination, capacity, booked_seats) VALUES (?, ?, ?, 0)";
	            pstmt = con.prepareStatement(query);
	            pstmt.setString(1, flight.getFlightNumber());
	            pstmt.setString(2, flight.getDestination());
	            pstmt.setInt(3, flight.getCapacity());
	            pstmt.executeUpdate();
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } finally {
	        	try {
					if(pstmt!=null)
						pstmt.close();
					else if(con!=null)
						con.close();
					
				}catch(SQLException e) {
					e.printStackTrace();
				}  // Now correctly closing PreparedStatement
	        }
	        System.out.println("Flight added successfully.");
	    }


	    @Override
	    public void viewFlights() {
	    	    Connection con = null;
	    	    Statement stmt = null;
	    	    ResultSet rs = null;

	    	    try {
	    	        con = DBConnection.getDBConnection();
	    	        
	    	        stmt = con.createStatement();
	    	        rs = stmt.executeQuery("SELECT flight_number, destination, capacity, booked_seats FROM Flights");

	    	        System.out.println("\nAvailable Flights:");
	    	        while (rs.next()) {
	    	            Flight flight = new Flight(
	    	                rs.getString("flight_number"),
	    	                rs.getString("destination"),
	    	                rs.getInt("capacity")
	    	            );
	    	            int availableSeats = flight.getCapacity() - rs.getInt("booked_seats");
	    	            System.out.println(flight + ", Available Seats: " + availableSeats);
	    	        }
	    	    } catch (SQLException e) {
	    	        e.printStackTrace();
	    	    } finally {
	    	    	try {
	    	    		if(rs!=null)
	    					rs.close();
	    				else if(con!=null)
	    					con.close();
	    				
	    			}catch(SQLException e) {
	    				e.printStackTrace();
	    			}
	    	    }
	    	}

	    

	    @Override
	    public void bookTicket(String flightNumber, String passengerName, String contactInfo) {
	        Connection con = null;
	        PreparedStatement pstmt = null;

	        try {
	            con = DBConnection.getDBConnection();

	            // Check seat availability
	           
	            pstmt = con.prepareStatement( "SELECT capacity, booked_seats FROM Flights WHERE flight_number = ?");
	            pstmt.setString(1, flightNumber);
	            ResultSet rs = pstmt.executeQuery();
	            if (rs.next()) {
	                if (rs.getInt("booked_seats") >= rs.getInt("capacity")) {
	                    System.out.println("No seats available on this flight.");
	                    return;
	                }
	            } else {
	                System.out.println("Flight not found.");
	                return;
	            }
	            pstmt.close();

	            // Add passenger
	            
	            pstmt = con.prepareStatement("INSERT INTO Passengers (name, contact_info) VALUES (?, ?)", Statement.RETURN_GENERATED_KEYS);
	            pstmt.setString(1, passengerName);
	            pstmt.setString(2, contactInfo);
	            pstmt.executeUpdate();
	            ResultSet passengerRs = pstmt.getGeneratedKeys();
	            int passengerId = -1;
	            if (passengerRs.next()) {
	                passengerId = passengerRs.getInt(1);
	            }
	            pstmt.close();

	            // Add reservation
	            String reservationId = "R" + new Random().nextInt(1000);
	          
	            pstmt = con.prepareStatement( "INSERT INTO Reservations (reservation_id, flight_number, passenger_id) VALUES (?, ?, ?)");
	            pstmt.setString(1, reservationId);
	            pstmt.setString(2, flightNumber);
	            pstmt.setInt(3, passengerId);
	            pstmt.executeUpdate();

	            // Update flight's booked seats
	            
	            pstmt = con.prepareStatement("UPDATE Flights SET booked_seats = booked_seats + 1 WHERE flight_number = ?");
	            pstmt.setString(1, flightNumber);
	            pstmt.executeUpdate();

	            System.out.println("Ticket booked successfully. Reservation ID: " + reservationId);
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } finally {
	        	try {
					if(pstmt!=null)
						pstmt.close();
					else if(con!=null)
						con.close();
					
				}catch(SQLException e) {
					e.printStackTrace();
				}
	        }
	    }

	    @Override
	    public void cancelTicket(String reservationId) {
	        Connection con = null;
	        PreparedStatement pstmt = null;

	        try {
	            con = DBConnection.getDBConnection();

	            // Retrieve flight number for reservation
	            String flightNumber = null;
	           
	            pstmt = con.prepareStatement( "SELECT flight_number FROM Reservations WHERE reservation_id = ?");
	            pstmt.setString(1, reservationId);
	            ResultSet rs = pstmt.executeQuery();
	            if (rs.next()) {
	                flightNumber = rs.getString("flight_number");
	            } else {
	                System.out.println("Reservation not found.");
	                return;
	            }
	            pstmt.close();

	            // Delete reservation
	            
	            pstmt = con.prepareStatement("DELETE FROM Reservations WHERE reservation_id = ?");
	            pstmt.setString(1, reservationId);
	            pstmt.executeUpdate();
	            pstmt.close();

	            // Update flight's booked seats
	            
	            pstmt = con.prepareStatement("UPDATE Flights SET booked_seats = booked_seats - 1 WHERE flight_number = ?");
	            pstmt.setString(1, flightNumber);
	            pstmt.executeUpdate();

	            System.out.println("Ticket cancelled successfully.");
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } finally {
	        	try {
					if(pstmt!=null)
						pstmt.close();
					else if(con!=null)
						con.close();
					
				}catch(SQLException e) {
					e.printStackTrace();
				}
	        }
	    }

	  
	  
}


